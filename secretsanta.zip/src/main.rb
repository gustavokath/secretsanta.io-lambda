# frozen_string_literal: true

require 'json'
require_relative './entities/participant'
require_relative './entities/event'
require_relative './services/sms_notification_service'
require_relative './services/email_notification_service'

# A class to run a Secret Santa draw
class SecretSanta
  def self.run(event:, context:)
    body = JSON.parse(event['body'])
    participants = body['participants'].map do |p|
      Participant.new(p['name'], p['language'], p['contact_method'], p['contact'])
    end
    secret_santa = Event.new(body['id'], body['name'], body['date'])

    result = draw(participants)
    notify_all(secret_santa, result) if result
  end

  def self.draw(participants)
    size = participants.length
    result = []
    return nil if size < 2

    until size.zero?
      index = rand(size)
      receiver = participants[index]
      participants[index] = participants[size - 1]

      result.push(receiver)
      size -= 1
    end
    result
  end

  def self.notify_all(event, participants)
    count = participants.length
    participants.each_with_index do |p, index|
      receiver = participants[(index + 1) % count]
      notify(event, p, receiver.name)
    end
  end

  def self.notify(event, giver, receiver_name)
    notifier = giver.sms? ? SMSNotificationService.new : EmailNotificationService.new

    notifier.notify!(event, giver, receiver_name)
  end
end
