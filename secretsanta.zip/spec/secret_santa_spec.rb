# frozen_string_literal: true

require 'spec_helper'
require 'faker'
require 'securerandom'
require './src/main'
require './src/entities/participant'
require './src/entities/event'
require './src/services/sms_notification_service'
require './src/services/email_notification_service'

RSpec.describe SecretSanta do
  let(:secret_santa_event) { Event.new(SecureRandom.uuid, Faker::Restaurant.name, '02/29/2020') }

  describe '.draw' do
    context 'when participants are correct' do
      let(:participants) do
        6.times.collect { Participant.new(Faker::Name.name, 'en', 'SMS', Faker::PhoneNumber.cell_phone_in_e164) }
      end

      subject { SecretSanta.draw(participants) }

      it 'should have each participant once' do
        result = subject
        participants.each do |p|
          expect(result.count(p)).to eq(1)
        end
      end

      it 'should have same size' do
        expect(subject.length).to eq(participants.length)
      end
    end

    context 'when less than 2 participants' do
      let(:participants) { [Participant.new(Faker::Name.name, 'en', 'SMS', Faker::PhoneNumber.cell_phone_in_e164)] }

      subject { SecretSanta.draw(participants) }

      it { is_expected.to be_nil }
    end
  end

  describe '.notify_all' do
    context 'when notify result' do
      let(:participants) do
        6.times.collect { Participant.new(Faker::Name.name, 'en', 'SMS', Faker::PhoneNumber.cell_phone_in_e164) }
      end

      before { allow(SecretSanta).to receive(:notify).and_return(nil) }

      subject { SecretSanta.notify_all(secret_santa_event, participants) }

      it 'notifies each participant' do
        expect(SecretSanta).to receive(:notify).exactly(participants.length)
        subject
      end

      it 'notifies each participant only once' do
        participants.each_with_index do |p, index|
          expect(SecretSanta).to receive(:notify).once.with(secret_santa_event,
                                                            p, participants[(index + 1) % participants.length].name)
        end
        subject
      end
    end
  end

  describe '.notify' do
    context 'when type is SMS' do
      let(:giver) { Participant.new(Faker::Name.name, 'en', 'SMS', Faker::PhoneNumber.cell_phone_in_e164) }
      let(:receiver) { Faker::Name.name }
      let(:sms_notifier) { SMSNotificationService.new }

      before do
        allow(SMSNotificationService).to receive(:new).and_return(sms_notifier)
        allow(sms_notifier).to receive(:notify!).and_return(nil)
      end

      subject { SecretSanta.notify(secret_santa_event, giver, receiver) }

      it 'should call SMS notifier' do
        expect(sms_notifier).to receive(:notify!).with(secret_santa_event, giver, receiver)
        subject
      end
    end

    context 'when type is EMAIL' do
      let(:giver) { Participant.new(Faker::Name.name, 'en', 'EMAIL', Faker::PhoneNumber.cell_phone_in_e164) }
      let(:receiver) { Faker::Name.name }
      let(:email_notifier) { EmailNotificationService.new }

      before do
        allow(EmailNotificationService).to receive(:new).and_return(email_notifier)
        allow(email_notifier).to receive(:notify!).and_return(nil)
      end

      subject { SecretSanta.notify(secret_santa_event, giver, receiver) }

      it 'should call email notifier' do
        expect(email_notifier).to receive(:notify!).with(secret_santa_event, giver, receiver)
        subject
      end
    end
  end
end
